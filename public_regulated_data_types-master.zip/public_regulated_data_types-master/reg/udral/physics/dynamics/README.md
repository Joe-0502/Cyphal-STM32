# Dynamic states

Dynamic states extend kinematic states (defined in the adjacent namespace) with forces acting on the body.
